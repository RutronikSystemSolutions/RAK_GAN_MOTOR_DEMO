C:/Projects/VS_PSC3_Test/RAK-GAN_Motor_Control_Demo/build/APP_RAK_GAN/Debug/rak-gan-motor-demo.hex
